# String yang dibutuhkan
str1="I love coding"
str2="i will become fullstack developer"

# LOOPING PERTAMA
print("LOOPING PERTAMA")

# Proses Looping pertama
num1 = 2
while num1 < 21:
    print(str(num1) + " - " + str1)
    num1 += 2

# LOOPING PERTAMA
print("LOOPING KEDUA")

#Proses Looping kedua
num2 = 20
while num2 > 0:
    print(str(num2)+ " - " + str2)
    num2 -= 2
