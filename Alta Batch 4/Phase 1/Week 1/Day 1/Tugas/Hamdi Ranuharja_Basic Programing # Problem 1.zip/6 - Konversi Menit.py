#Input 1
Waktu = 63
mod=str(Waktu%60)
if len(mod) == 2 :
    print(str(int(Waktu/60)) + ":" + mod )
else :
    print(str(int(Waktu/60)) + ":0" + mod )

#Input 2
Waktu = 124
mod=str(Waktu%60)
if len(mod) == 2 :
    print(str(int(Waktu/60)) + ":" + mod )
else :
    print(str(int(Waktu/60)) + ":0" + mod )

#Input 3
Waktu = 53
mod=str(Waktu%60)
if len(mod) == 2 :
    print(str(int(Waktu/60)) + ":" + mod )
else :
    print(str(int(Waktu/60)) + ":0" + mod )

#Input 4
Waktu = 88
mod=str(Waktu%60)
if len(mod) == 2 :
    print(str(int(Waktu/60)) + ":" + mod )
else :
    print(str(int(Waktu/60)) + ":0" + mod )

#Input 5
Waktu = 120
mod=str(Waktu%60)
if len(mod) == 2 :
    print(str(int(Waktu/60)) + ":" + mod )
else :
    print(str(int(Waktu/60)) + ":0" + mod )