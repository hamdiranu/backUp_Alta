# String yang dibutuhkan
str1 = "I love coding"
str2 = "I will become fullstack developer"

# Looping pertama
print("LOOPING PERTAMA")

# Proses

for angka in range(2, 21, 2):
    print(str(angka) + " - " + str1)

# Looping kedua
print("LOOPING KEDUA")

# Proses

for angka in range(20, 1, -2):
    print(str(angka) + " - " + str2)
