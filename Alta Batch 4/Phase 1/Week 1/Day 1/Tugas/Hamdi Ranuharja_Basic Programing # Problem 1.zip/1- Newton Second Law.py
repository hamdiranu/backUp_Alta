
# INPUT 1
# Problem Newton Second Law
# Input: m = 600, a = 2
m = 600
a = 2

resultan_gaya = m * a

# Output
print("Output: " + str(resultan_gaya))

# INPUT 2
# Problem Newton Second Law
# Input: m = 600, a = 2
m = 70
a = 3

resultan_gaya = m * a

# Output
print("Output: " + str(resultan_gaya))