# Proses 1
n="lane borrowed"
b=0
for i in n :
    if i == 'a':
        if n[n.index('a') + 4] == 'b':
            b += 1
            break
    if i == 'b':
        if n[n.index('b') + 4] == 'a':
            b += 1
            break
    else :
        continue

if b==0:
    print("False")
else :
    print("True")

print('')

# Proses 2
n="i am sick"
b=0
for i in n :
    if i == 'a':
        if n[n.index('a') + 4] == 'b':
            b += 1
            break
    if i == 'b':
        if n[n.index('b') + 4] == 'a':
            b += 1
            break
    else :
        continue

if b==0:
    print("False")
else :
    print("True")
print('')

# Proses 3
n="you are boring"
b=0
for i in n :
    if i == 'a':
        if n[n.index('a') + 4] == 'b':
            b += 1
            break
    if i == 'b':
        if n[n.index('b') + 4] == 'a':
            b += 1
            break
    else :
        continue

if b==0:
    print("False")
else :
    print("True")
print('')

# Proses 4
n="barbarian"
b=0
for i in n :
    if i == 'a':
        if n[n.index('a') + 4] == 'b':
            b += 1
            break
    if i == 'b':
        if n[n.index('b') + 4] == 'a':
            b += 1
            break
    else :
        continue

if b==0:
    print("False")
else :
    print("True")
print('')

# Proses 5
n="bacon and meat"
b=0
for i in n :
    if i == 'a':
        if n[n.index('a') + 4] == 'b':
            b += 1
            break
    if i == 'b':
        if n[n.index('b') + 4] == 'a':
            b += 1
            break
    else :
        continue

if b==0:
    print("False")
else :
    print("True")

print(' ')