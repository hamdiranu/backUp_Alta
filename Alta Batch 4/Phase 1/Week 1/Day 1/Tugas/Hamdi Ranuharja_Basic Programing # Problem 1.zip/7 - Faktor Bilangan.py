# Input 1
n = 6
print("Input: " + str(n))
hasil=[]
faktor = 0 # initial value untuk jumlah faktor
for i in range(1, n+1):
    if n % i == 0 :
        faktor += 1
        hasil.append(str(i))

akhir=' '.join(hasil) # untuk merapikan susunan listnya
print("Output: "+str(akhir))
print(" ") # supaya enak dilihat

# Input 2
n = 12
print("Input: " + str(n))
hasil=[]
faktor = 0 # initial value untuk jumlah faktor
for i in range(1, n+1):
    if n % i == 0 :
        faktor += 1
        hasil.append(str(i))

akhir=' '.join(hasil) # untuk merapikan susunan listnya
print("Output: "+str(akhir))
print(" ") # supaya enak dilihat

# Input 3
n = 14
print("Input: " + str(n))
hasil=[]
faktor = 0 # initial value untuk jumlah faktor
for i in range(1, n+1):
    if n % i == 0 :
        faktor += 1
        hasil.append(str(i))

akhir=' '.join(hasil) # untuk merapikan susunan listnya
print("Output: "+str(akhir))
print(" ") # supaya enak dilihat

# Input 4
n = 16
print("Input: " + str(n))
hasil=[]
faktor = 0 # initial value untuk jumlah faktor
for i in range(1, n+1):
    if n % i == 0 :
        faktor += 1
        hasil.append(str(i))

akhir=' '.join(hasil) # untuk merapikan susunan listnya
print("Output: "+str(akhir))
print(" ") # supaya enak dilihat

# Input 5
n = 20
print("Input: " + str(n))
hasil=[]
faktor = 0 # initial value untuk jumlah faktor
for i in range(1, n+1):
    if n % i == 0 :
        faktor += 1
        hasil.append(str(i))

akhir=' '.join(hasil) # untuk merapikan susunan listnya
print("Output: "+str(akhir))