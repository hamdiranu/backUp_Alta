#Input 1
n = "xoxoxo"
print("Input: xoxoxo")
if n.count('x') == n.count('o') :
    print("Output: True")
else :
    print("Output: False")

print(" ")

#Input 2
n = "oxooxo"
print("Input: oxooxo")
if n.count('x') == n.count('o') :
    print("Output: True")
else :
    print("Output: False")

print(" ")

#Input 3
n = "oxo"
print("Input: oxo")
if n.count('x') == n.count('o') :
    print("Output: True")
else :
    print("Output: False")

print(" ")

#Input 4
n = "xxxooo"
print("Input: xxxooo")
if n.count('x') == n.count('o') :
    print("Output: True")
else :
    print("Output: False")

print(" ")

#Input 5
n = "xoxooxxo"
print("Input: xoxooxxo")
if n.count('x') == n.count('o') :
    print("Output: True")
else :
    print("Output: False")

print(" ")